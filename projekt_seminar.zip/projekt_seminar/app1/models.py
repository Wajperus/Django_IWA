from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager as DefaultUserManager
# Create your models here.

class Role(models.Model):
    ROLES = (
        ('prof', 'profesor'),
        ('admin', 'administrator'),
        ('stud', 'student'),
    )
    name = models.CharField(max_length=50, choices=ROLES)

    def __str__(self):
        return self.get_name_display()

class UserManager(DefaultUserManager):
    pass

class Korisnik(AbstractUser):
    objects=UserManager()
    #ROLES=(('prof','profesor'),('admin','administrator'),('stud','student'))
    STATUS=(('red','redovan'),('izv','izvanredan'),('non','none'))
    role=models.ForeignKey(Role,on_delete=models.SET_NULL,null=True)
    status=models.CharField(max_length=50,choices=STATUS)

class Predmet(models.Model):
    IZBORNI=(('d','da'),('n','ne'))
    name=models.CharField(max_length=50)
    kod=models.CharField(max_length=10)
    program=models.CharField(max_length=255)
    ects=models.IntegerField(null=True)
    sem_red=models.IntegerField(null=True)
    sem_izv=models.IntegerField(null=True)
    izborni=models.CharField(max_length=10,choices=IZBORNI)
    nositelj=models.ForeignKey(Korisnik,on_delete=models.CASCADE, limit_choices_to={'role__name':'prof'}, null=True)
    
    def __str__(self):
        return '%s %s' % (self.name,self.ects)

class Upisi(models.Model):
    STATUS=(('pass','passed'),('enr','enrolled'),('not','notenrolled'),('fai','failed'))
    student=models.ForeignKey(Korisnik, on_delete=models.CASCADE)
    predmet=models.ForeignKey(Predmet, on_delete=models.CASCADE)
    status=models.CharField(max_length=50,choices=STATUS)
