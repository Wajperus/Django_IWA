from django.contrib.auth import authenticate, login, get_user_model, logout
from .forms import KorisnikCreationForm
from django.shortcuts import render, redirect, get_object_or_404
from .models import Korisnik, Predmet, Upisi
from django import forms
from .forms import PredmetForm, StudentForm, ProfessorForm, StudentSubjectsForm, EnrollmentStatusForm
from django.core.exceptions import ValidationError
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views.decorators.cache import never_cache #dodajemo kako stranica ne bi kasnila tj podaci se povlace odma sa servera
# Create your views here.



def login_view(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            if user.role.name=='admin':
                return redirect('admin_page')
            elif user.role.name=='prof':
                return redirect('professor_page')
            elif user.role.name=='stud':
                return redirect('student_page')
        else:
            return render(request,'login.html',{'error':'Neispravno korisničko ime ili lozinka'})
    return render(request,'login.html')

def register_view(request):
    if request.method == 'POST':
        form=KorisnikCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form=KorisnikCreationForm()
    return render(request,'register.html',{'form':form})

def admin_page_view(request):
    if request.user.is_authenticated and request.user.role.name=='admin':
        subjects=Predmet.objects.all()
        return render(request,'admin_page.html', {'subjects':subjects})
    else:
        return redirect('login')
    
def admin_subjects_view(request):
    if request.user.is_authenticated and request.user.role.name=='admin':
        if request.method=='POST':
            form=PredmetForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('admin_subjects')
        else:
            form=PredmetForm()
        subjects=Predmet.objects.all()
        return render(request,'admin_subjects.html',{'form':form,'subjects':subjects})
    else:
        return redirect('login')    
    
def edit_subject(request, subject_id):
    subject=get_object_or_404(Predmet,pk=subject_id) #pokusava dohvatit objekt za datu klasu
    if request.method=='POST':
        form=PredmetForm(request.POST,instance=subject)
        if form.is_valid():
            form.save()
            return redirect('admin_page')
    else:
        form=PredmetForm(instance=subject)
    return render(request,'edit_subject.html',{'form':form})

def view_students(request):
    students=Korisnik.objects.filter(role__name='stud')
    return render(request,'view_students.html',{'students':students})

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_page')
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})

def view_professors(request):
    professors = Korisnik.objects.filter(role__name='prof')
    return render(request, 'view_professors.html', {'professors': professors})

def add_professor(request):
    if request.method == 'POST':
        form = ProfessorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_page')
    else:
        form = ProfessorForm()
    return render(request, 'add_professor.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

def edit_student(request, student_id):
    student = get_object_or_404(Korisnik, pk=student_id)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentForm(instance=student)
    return render(request, 'edit_student.html', {'form': form})

def edit_professor(request, professor_id):
    professor = get_object_or_404(Korisnik, pk=professor_id)
    if request.method == 'POST':
        form = ProfessorForm(request.POST, instance=professor)
        if form.is_valid():
            form.save()
            return redirect('view_professors')
    else:
        form = ProfessorForm(instance=professor)
    return render(request, 'edit_professor.html', {'form': form})


def view_students_for_subject(request, subject_id):
    subject = get_object_or_404(Predmet, pk=subject_id)
    upisi_for_subject = Upisi.objects.filter(predmet=subject)
    students = [upis.student for upis in upisi_for_subject]
    return render(request, 'view_students_for_subject.html', {'students': students, 'subject': subject})

def edit_student_subjects(request, student_id):
    student = get_object_or_404(Korisnik, pk=student_id)
    if request.method == 'POST':
        subject_ids = request.POST.getlist('subjects')
        subjects = Predmet.objects.filter(id__in=subject_ids)
        Upisi.objects.filter(student=student).delete()
        for subject in subjects:
            Upisi.objects.create(student=student, predmet=subject)
        return redirect('view_students')
    else:
        enrolled_subjects = Upisi.objects.filter(student=student).values_list('predmet', flat=True)
        form = StudentSubjectsForm(initial={'subjects': enrolled_subjects})
    return render(request, 'edit_student_subjects.html', {'form': form, 'student': student})


#ZA STUDENTA

# def student_page_view(request):
#     if request.user.is_authenticated and request.user.role.name=='stud':
#         subjects=Predmet.objects.all()
#         return render(request,'student_page.html', {'subjects':subjects, 'student': request.user})
#     else:
#         return redirect('login')

def student_page_view(request):
    if request.user.is_authenticated and request.user.role.name=='stud':
        student = request.user
        subjects = Predmet.objects.all()
        enrolled_subjects = Upisi.objects.filter(student=student).values_list('predmet', flat=True)
        context = {
            'student': student,
            'subjects': subjects,
            'enrolled_subjects': enrolled_subjects,
        }
        return render(request, 'student_page.html', context)
    else:
        return redirect('login')
    
def enroll_subject(request, subject_id, student_id):
    if request.user.is_authenticated and request.user.role.name=='stud':
        subject = Predmet.objects.get(id=subject_id)
        try:
            Upisi.objects.get(student=request.user, predmet=subject)
        except Upisi.DoesNotExist:
            Upisi.objects.create(student=request.user, predmet=subject, status='enr')
        return HttpResponseRedirect(reverse('student_page'))
    else:
        return redirect('login')

def unenroll_subject(request, subject_id, student_id):
    if request.user.is_authenticated and request.user.role.name=='stud':
        subject = Predmet.objects.get(id=subject_id)
        try:
            upis = Upisi.objects.get(student=request.user, predmet=subject)
            upis.delete()
        except Upisi.DoesNotExist:
            pass
        return HttpResponseRedirect(reverse('student_page'))
    else:
        return redirect('login')
    


# ZA PROFESORA

def professor_page_view(request):
    if request.user.is_authenticated and request.user.role.name=='prof':
        professor = request.user
        subjects = Predmet.objects.filter(nositelj=professor)
        return render(request, 'professor_page.html', {'professor': professor, 'subjects': subjects})
    else:
        return redirect('login')

def subject_students_view(request, subject_id):
    if request.user.is_authenticated and request.user.role.name=='prof':
        subject = Predmet.objects.get(id=subject_id)
        enrollments = Upisi.objects.filter(predmet=subject, status='enr')
        students = [enrollment.student for enrollment in enrollments]
        return render(request, 'subject_students.html', {'subject': subject, 'students': students})
    else:
        return redirect('login')
    
@never_cache
def subject_students_view(request, subject_id):
    if request.user.is_authenticated and request.user.role.name=='prof':
        subject = Predmet.objects.get(id=subject_id)
        enrollments = Upisi.objects.filter(predmet=subject)
        forms = {enrollment.student.username: EnrollmentStatusForm(instance=enrollment) for enrollment in enrollments}
        if request.method == 'POST':
            student_username = request.POST['student_username']
            enrollment = Upisi.objects.get(student__username=student_username, predmet=subject)
            form = EnrollmentStatusForm(request.POST, instance=enrollment)
            if form.is_valid():
                form.save()
                forms[student_username] = EnrollmentStatusForm(instance=enrollment)  # Re-instantiate the form
        return render(request, 'subject_students.html', {'subject': subject, 'forms': forms})
    else:
        return redirect('login')

def subject_students_criteria_view(request, subject_id):
    if request.user.is_authenticated and request.user.role.name=='prof':
        subject = Predmet.objects.get(id=subject_id)
        students_lost_signature = Upisi.objects.filter(predmet=subject, status='not')
        students_got_signature = Upisi.objects.filter(predmet=subject, status='enr')
        students_passed = Upisi.objects.filter(predmet=subject, status='pass')
        return render(request, 'subject_students_criteria.html', {
            'subject': subject, 
            'students_lost_signature': students_lost_signature, 
            'students_got_signature': students_got_signature, 
            'students_passed': students_passed
        })
    else:
        return redirect('login')

# def some_view(request):
#     if request.user.is_authenticated:
#         if request.user.role=='admin':
#             return render(request,'admin_page.html')
#         elif request.user.role=='prof':
#             return render(request,'professor_page.html')
#         elif request.user.role=='stud':
#             return render(request,'student_page.html')
#     else:
#         return redirect('login')


# def lista_predmeta(request):
#     if request.user.is_authenticated:
#         if request.user.role=='stud':
#             predmeti=Predmet.objects.filter(upisi_student=request.user)
#         else:
#             predmeti=Predmet.objects.all()
#     else:
#         predmeti=Predmet.objects.all()
#     return render(request,'lista_predmeta.html',{'predmeti':predmeti})