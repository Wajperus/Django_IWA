from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from .models import Korisnik
from django import forms
from .models import Predmet, Upisi, Role

class KorisnikCreationForm(UserCreationForm):
    class Meta:
        model=Korisnik
        fields=UserCreationForm.Meta.fields + ('role',)
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if get_user_model().objects.filter(username__iexact=username).exists():
            raise ValidationError("A user with that username already exists.")
        return username
    
class KorisnikUpdateForm(forms.ModelForm):
    class Meta:
        model=Korisnik
        fields=('username','role','status')

class PredmetForm(forms.ModelForm):
    class Meta:
        model=Predmet
        fields=['name','kod','program','ects','sem_red','sem_izv','izborni','nositelj']

class UpisiForm(forms.ModelForm):
    class Meta:
        model=Upisi
        fields=['student','predmet','status']


class StudentForm(forms.ModelForm):
    class Meta:
        model = Korisnik
        fields = ['username', 'password', 'status', 'role']  # Dodajte polja koja su potrebna za studente

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['role'].initial = Role.objects.get(name='stud')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user
    
class ProfessorForm(forms.ModelForm):
    class Meta:
        model = Korisnik
        fields = ['username', 'password', 'status', 'role']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['role'].initial = Role.objects.get(name='prof')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user

class StudentSubjectsForm(forms.Form):
    subjects = forms.ModelMultipleChoiceField(queryset=Predmet.objects.all(), widget=forms.CheckboxSelectMultiple)

class EnrollmentStatusForm(forms.ModelForm):
    class Meta:
        model = Upisi
        fields = ['status']
        