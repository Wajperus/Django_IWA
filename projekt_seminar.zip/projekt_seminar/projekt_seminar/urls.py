"""
URL configuration for projekt_seminar project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app1 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('admin_page/', views.admin_page_view, name='admin_page'),
    path('admin_subjects/', views.admin_subjects_view, name='admin_subjects'),
    path('edit_subject/<int:subject_id>/', views.edit_subject, name='edit_subject'),
    path('add_student/', views.add_student, name='add_student'),
    path('view_students/', views.view_students, name='view_students'),
    path('edit_student/<int:student_id>/', views.edit_student, name='edit_student'),
    path('view_students_for_subject/<int:subject_id>/', views.view_students_for_subject, name='view_students_for_subject'),
    path('edit_student_subjects/<int:student_id>/', views.edit_student_subjects, name='edit_student_subjects'),
    path('add_professor/', views.add_professor, name='add_professor'),
    path('view_professors/', views.view_professors, name='view_professors'),
    path('edit_professor/<int:professor_id>/', views.edit_professor, name='edit_professor'),
    path('student_page/', views.student_page_view, name='student_page'),
    path('enroll_subject/<int:student_id>/<int:subject_id>/', views.enroll_subject, name='enroll_subject'),
    path('unenroll_subject/<int:student_id>/<int:subject_id>/', views.unenroll_subject, name='unenroll_subject'),
    path('professor_page/', views.professor_page_view, name='professor_page'),
    path('subject_students/<int:subject_id>/', views.subject_students_view, name='subject_students'),
    path('subject_students_criteria/<int:subject_id>/', views.subject_students_criteria_view, name='subject_students_criteria'),
    path('logout/', views.logout_view, name='logout'),
]
